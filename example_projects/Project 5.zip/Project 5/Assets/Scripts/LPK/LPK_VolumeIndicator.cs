﻿/***************************************************
File:           LPK_VolumeIndicator.cs
Authors:        Christopher Onorati
Last Updated:   7/30/2019
Last Version:   2018.3.14

Description: 
  This component is an indicator to display the current
  volume level of a sound type on a UI screen.  This should
  ideally be used on a canvas represting the options
  screen.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEngine.UI;   /*Text */
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_VolumeIndicator
* DESCRIPTION : Indicator to show what level the volume is at.
**/
[RequireComponent(typeof(Text))]
public class LPK_VolumeIndicator : LPK_Component
{
    /************************************************************************************/

    public enum LPK_AudioDisplayType
    {
        SFX,
        MUSIC,
        VOICE,
        MASTER,
    };

    /************************************************************************************/

    [Tooltip("Type of audio this game object will emit.  Note that each game object should only emit one audio file.")]
    [Rename("Audio Type")]
    public LPK_AudioDisplayType m_eAudioType;

    /************************************************************************************/

    Text m_cText;

    /**
    * FUNCTION NAME: Start
    * DESCRIPTION  : Connects to event listening and initial display.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Start()
    {
        m_cText = gameObject.GetComponent<Text>();

        UpdateText();
    }

    /**
    * FUNCTION NAME: OnAudioLevelsChange
    * DESCRIPTION  : Update the text on the volume display.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public void UpdateText()
    {
        if (m_eAudioType == LPK_AudioDisplayType.MUSIC)
            m_cText.text = Mathf.RoundToInt(LPK_VolumeManager.m_flMusicLevel * 10).ToString();
        else if (m_eAudioType == LPK_AudioDisplayType.SFX)
            m_cText.text = Mathf.RoundToInt(LPK_VolumeManager.m_flSFXLevel * 10).ToString();
        else if (m_eAudioType == LPK_AudioDisplayType.VOICE)
            m_cText.text = Mathf.RoundToInt(LPK_VolumeManager.m_flVoiceLevel * 10).ToString();
        else if (m_eAudioType == LPK_AudioDisplayType.MASTER)
            m_cText.text = Mathf.RoundToInt(LPK_VolumeManager.m_flMasterLevel * 10).ToString();

        if (m_bPrintDebug)
            LPK_PrintDebug(this, "Changing text display.");    
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_VolumeIndicator))]
public class LPK_VolumeIndicatorEditor : Editor
{
    SerializedProperty audioType;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        audioType = serializedObject.FindProperty("m_eAudioType");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_VolumeIndicator owner = (LPK_VolumeIndicator)target;

        LPK_VolumeIndicator editorOwner = owner.GetComponent<LPK_VolumeIndicator>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_VolumeIndicator)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_VolumeIndicator), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_VolumeIndicator");

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Base Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(audioType, true);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
