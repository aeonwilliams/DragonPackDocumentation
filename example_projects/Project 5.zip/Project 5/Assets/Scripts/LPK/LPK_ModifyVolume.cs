﻿/***************************************************
File:           LPK_ModifyVolume.cs
Authors:        Christopher Onorati
Last Updated:   7/30/2019
Last Version:   2018.3.14

Description:
  Implementation of a volume manager to adjust Audio Source
  volumes based on the type of FX they play at runtime.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_ModifyVolume
* DESCRIPTION : Component to modify audio volumes at run time.
**/
[RequireComponent(typeof(AudioSource))]
[DisallowMultipleComponent]
public class LPK_ModifyVolume : LPK_Component
{
    [Tooltip("Type of audio this game object will emit.  Note that each game object should only emit one audio file.")]
    [Rename("Audio Type")]
    public LPK_VolumeManager.LPK_AudioType m_eAudioType;

    /************************************************************************************/

    AudioSource m_cAudioSource;

    /**
    * FUNCTION NAME: Start
    * DESCRIPTION  : Connects to event listening.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Start()
    {
        m_cAudioSource = GetComponent<AudioSource>();

        //Set initial audio levels.
        SetAudioLevel();
    }

    /**
    * FUNCTION NAME: OnAudioLevelsChange
    * DESCRIPTION  : Call the Audio Source's volume.
    * INPUTS       : _data - Event registration data (unused).
    * OUTPUTS      : None
    **/
    public void UpdateAudioLevels()
    {
        SetAudioLevel();
    }

    /**
    * FUNCTION NAME: SetAudioLevel
    * DESCRIPTION  : Adjusts the Audio Source's volume.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void SetAudioLevel()
    {
        if (m_eAudioType == LPK_VolumeManager.LPK_AudioType.MUSIC)
            m_cAudioSource.volume = LPK_VolumeManager.m_flMusicLevel * LPK_VolumeManager.m_flMasterLevel;
        else if (m_eAudioType == LPK_VolumeManager.LPK_AudioType.SFX)
            m_cAudioSource.volume = LPK_VolumeManager.m_flSFXLevel * LPK_VolumeManager.m_flMasterLevel;
        else if (m_eAudioType == LPK_VolumeManager.LPK_AudioType.VOICE)
            m_cAudioSource.volume = LPK_VolumeManager.m_flVoiceLevel * LPK_VolumeManager.m_flMasterLevel;
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_ModifyVolume))]
public class LPK_ModifyVolumeEditor : Editor
{
    SerializedProperty audioType;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        audioType = serializedObject.FindProperty("m_eAudioType");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_ModifyVolume owner = (LPK_ModifyVolume)target;

        LPK_ModifyVolume editorOwner = owner.GetComponent<LPK_ModifyVolume>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_ModifyVolume)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_ModifyVolume), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_ModifyVolume");

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(audioType, true);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}
