﻿/***************************************************
File:           LPK_DispatchOnVisibility.cs
Authors:        Christopher Onorati
Last Updated:   6/10/2019
Last Version:   2018.3.14

Description:
  This component detects when a game object changes
  its rendered state (on or off screen) and sends
  events accordingly.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_DispatchOnVisibility
* DESCRIPTION : Dispatches events when the game object changes its visibility status.
**/
[RequireComponent(typeof(Renderer))]
public class LPK_DispatchOnVisibility : LPK_Component
{
    /************************************************************************************/

    public enum LPK_VisibilityCheckType
    {
        VISIBLITY_ENTER_SCREEN = 1,
        VISIBLITY_EXIT_SCREEN = 2,
        VISIBLITY_PERSIST_ON_SCREEN = 4,
        VISIBLITY_PERSIST_OFF_SCREEN = 8,
    };

    /************************************************************************************/

    public LPK_VisibilityCheckType m_VisibilityCheckType;

    [Header("Event Sending Info")]

    [Tooltip("Event sent when the game object enters the screen.")]
    public LPK_EventSendingInfo m_EnterScreenEvent;

    [Tooltip("Event sent when the game object exits the screen.")]
    public LPK_EventSendingInfo m_ExitScreenEvent;

    [Tooltip("Event sent when the game object stays on the screen.")]
    public LPK_EventSendingInfo m_PersistOnScreenEvent;

    [Tooltip("Event sent when the game object stays off the screen.")]
    public LPK_EventSendingInfo m_PersistOffScreenEvent;

    /************************************************************************************/

    //Used to detect if a game object is on screen.
    bool m_bIsVisible = false;

    /************************************************************************************/

    Renderer m_cRenderer;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Cache the renderer component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    protected override void OnStart()
    {
        m_cRenderer = GetComponent<Renderer>();
    }

    /**
    * FUNCTION NAME: Update
    * DESCRIPTION  : Checks visibility for event sending every frame.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Update()
    {
        CheckVisibility();
    }

    /**
    * FUNCTION NAME: CheckVisibility
    * DESCRIPTION  : Object visibility detection.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void CheckVisibility()
    {
        //Game object now on screen.
        if (m_cRenderer.isVisible)
        {
            //Enter screen.
            if (!m_bIsVisible && m_VisibilityCheckType == LPK_VisibilityCheckType.VISIBLITY_ENTER_SCREEN)
            {
                if(m_EnterScreenEvent != null && m_EnterScreenEvent.m_Event != null)
                {
                    if(m_EnterScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.ALL)
                        m_EnterScreenEvent.m_Event.Dispatch(null);
                    else if(m_EnterScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.OWNER)
                        m_EnterScreenEvent.m_Event.Dispatch(gameObject);

                    if (m_bPrintDebug)
                        LPK_PrintDebug(this, "Enter Screen event dispatched");
                }
            }

            //Enter screen persist.
            if (m_bIsVisible && m_VisibilityCheckType == LPK_VisibilityCheckType.VISIBLITY_PERSIST_ON_SCREEN)
            {
                if(m_PersistOnScreenEvent != null && m_PersistOnScreenEvent.m_Event != null)
                {
                    if(m_PersistOnScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.ALL)
                        m_PersistOnScreenEvent.m_Event.Dispatch(null);
                    else if(m_PersistOnScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.OWNER)
                        m_PersistOnScreenEvent.m_Event.Dispatch(gameObject);

                    if (m_bPrintDebug)
                        LPK_PrintDebug(this, "Persist On Screen event dispatched");
                }
            }

            m_bIsVisible = true;
        }

        //Game object now off screen.
        else if (m_cRenderer && !m_cRenderer.isVisible)
        {
            //Exit screen.
            if (m_bIsVisible && m_VisibilityCheckType == LPK_VisibilityCheckType.VISIBLITY_EXIT_SCREEN)
            {
                if(m_ExitScreenEvent != null && m_ExitScreenEvent.m_Event != null)
                {
                    if(m_ExitScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.ALL)
                        m_ExitScreenEvent.m_Event.Dispatch(null);
                    else if(m_ExitScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.OWNER)
                        m_ExitScreenEvent.m_Event.Dispatch(gameObject);

                    if (m_bPrintDebug)
                        LPK_PrintDebug(this, "Exit Screen event dispatched");
                }
            }

            //Exit screen persist.
            if (!m_bIsVisible && m_VisibilityCheckType == LPK_VisibilityCheckType.VISIBLITY_PERSIST_OFF_SCREEN)
            {
                if(m_PersistOffScreenEvent != null && m_PersistOffScreenEvent.m_Event != null)
                {
                    if(m_PersistOffScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.ALL)
                        m_PersistOffScreenEvent.m_Event.Dispatch(null);
                    else if(m_PersistOffScreenEvent.m_EventSendingMode == LPK_EventSendingInfo.LPK_EventSendingMode.OWNER)
                        m_PersistOffScreenEvent.m_Event.Dispatch(gameObject);

                    if (m_bPrintDebug)
                        LPK_PrintDebug(this, "Perist Off Screen event dispatched");
                }
            }

            m_bIsVisible = false;
        }
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_DispatchOnVisibility))]
public class LPK_DispatchOnVisibilityEditor : Editor
{
    SerializedProperty m_VisibilityCheckTypes;

    SerializedProperty m_EnterScreenEvent;
    SerializedProperty m_ExitScreenEvent;
    SerializedProperty m_PersistOnScreenEvent;
    SerializedProperty m_PersistOffScreenEvent;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        m_VisibilityCheckTypes = serializedObject.FindProperty("m_VisibilityCheckTypes");

        m_EnterScreenEvent = serializedObject.FindProperty("m_EnterScreenEvent");
        m_ExitScreenEvent = serializedObject.FindProperty("m_ExitScreenEvent");
        m_PersistOnScreenEvent = serializedObject.FindProperty("m_PersistOnScreenEvent");
        m_PersistOffScreenEvent = serializedObject.FindProperty("m_PersistOffScreenEvent");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_DispatchOnAnimatorCycle owner = (LPK_DispatchOnAnimatorCycle)target;

        LPK_DispatchOnAnimatorCycle editorOwner = owner.GetComponent<LPK_DispatchOnAnimatorCycle>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_DispatchOnAnimatorCycle)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_DispatchOnAnimatorCycle), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_PathFollower");

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Base Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        LPK_EditorArrayDraw.DrawArray(m_VisibilityCheckTypes, LPK_EditorArrayDraw.LPK_EditorArrayDrawMode.DRAW_MODE_BUTTONS);

        //Events
        EditorGUILayout.PropertyField(m_EnterScreenEvent, true);
        EditorGUILayout.PropertyField(m_ExitScreenEvent, true);
        EditorGUILayout.PropertyField(m_PersistOnScreenEvent, true);
        EditorGUILayout.PropertyField(m_PersistOffScreenEvent, true);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
