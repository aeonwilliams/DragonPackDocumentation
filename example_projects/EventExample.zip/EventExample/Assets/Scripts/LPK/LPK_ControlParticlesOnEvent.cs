﻿/***************************************************
File:           LPK_ControlParticlesOnEvent.cs
Authors:        Christopher Onorati
Last Updated:   5/20/2019
Last Version:   2018.3.14

Description:
  This component can be used to control the active state
  of a particle system, when an event is received.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_ControlParticlesOnEvent
* DESCRIPTION : Class to modify properties of a particle system during gameplay.
**/
public class LPK_ControlParticlesOnEvent : LPK_Component
{
    /************************************************************************************/

    public enum LPK_ToggleType
    {
        ON,
        OFF,
        TOGGLE,
    };

    /************************************************************************************/

    [Tooltip("Object to modify particle active state when the specified event is received.")]
    [Rename("Target Modify Object")]
    public GameObject m_pTargetModifyObject;

    [Tooltip("Object to modify particle active state when the specified event is received.  Note this will only affect the first object with the tag found.")]
    [TagDropdown]
    public string m_TargetModifyTag;

    [Tooltip("Set how to change the active state of the particle system.")]
    [Rename("Toggle Type")]
    public LPK_ToggleType m_eToggleType;

    [Header("Event Receiving Info")]

    [Tooltip("Which event will trigger this component's action")]
    public LPK_EventObject m_EventTrigger;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Sets up what event to listen to particle active state changing.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        if(m_EventTrigger != null)
            m_EventTrigger.Register(this);
        
        if (m_pTargetModifyObject == null)
        {
            if (!string.IsNullOrEmpty(m_TargetModifyTag))
            {
                m_pTargetModifyObject = LPK_MultiTagManager.FindGameObjectWithTag(gameObject, m_TargetModifyTag);

                if(LPK_MultiTagManager.FindGameObjectsWithTag(gameObject, m_TargetModifyTag).Count > 1 && m_bPrintDebug)
                    LPK_PrintWarning(this, "WARNNG: Undefined behavior!  Multiple game objects found with the tag: " + m_TargetModifyTag + 
                                     "Please note that in a build, it is undefined which game object will be selected.");
            }
            else
                m_pTargetModifyObject = gameObject;
        }
    }

    /**
    * FUNCTION NAME: OnEvent
    * DESCRIPTION  : Event validation.
    * INPUTS       : _activator - Game object that activated the event.  Null is all objects.
    * OUTPUTS      : None
    **/
    override public void OnEvent(GameObject _activator)
    {
        if(!ShouldRespondToEvent(_activator))
            return;
        
        if(!m_pTargetModifyObject.GetComponent<ParticleSystem>())
        {
            if (m_bPrintDebug)
                LPK_PrintDebug(this, "No particle system found on target object.");
        }

        ParticleSystem modifyParticles = m_pTargetModifyObject.GetComponent<ParticleSystem>();

        //Modify active state of particles.
        if (m_eToggleType == LPK_ToggleType.ON)
            modifyParticles.Play();
        else if (m_eToggleType == LPK_ToggleType.OFF)
            modifyParticles.Stop();
        else if (m_eToggleType == LPK_ToggleType.TOGGLE)
        {
            if (modifyParticles.isPlaying)
                modifyParticles.Stop();
            else
                modifyParticles.Play();
        }
    }

    /**
    * FUNCTION NAME: OnDestroy
    * DESCRIPTION  : Removes game object from the event queue.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnDestroy()
    {
        if(m_EventTrigger != null)
            m_EventTrigger.Unregister(this);
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_ControlParticlesOnEvent))]
public class LPK_ControlParticlesOnEventEditor : Editor
{
    SerializedProperty targetModifyObject;
    SerializedProperty targetModifyTag;
    SerializedProperty toggleType;

    SerializedProperty eventTriggers;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        targetModifyObject = serializedObject.FindProperty("m_pTargetModifyObject");
        targetModifyTag = serializedObject.FindProperty("m_TargetModifyTag");
        toggleType = serializedObject.FindProperty("m_eToggleType");

        eventTriggers = serializedObject.FindProperty("m_EventTrigger");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_ControlParticlesOnEvent owner = (LPK_ControlParticlesOnEvent)target;

        LPK_ControlParticlesOnEvent editorOwner = owner.GetComponent<LPK_ControlParticlesOnEvent>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_ControlParticlesOnEvent)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_ControlParticlesOnEvent), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_ControlParticlesOnEvent");

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(targetModifyObject, true);
        EditorGUILayout.PropertyField(targetModifyTag, true);
        EditorGUILayout.PropertyField(toggleType, true);

        //Events
        EditorGUILayout.PropertyField(eventTriggers, true);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
