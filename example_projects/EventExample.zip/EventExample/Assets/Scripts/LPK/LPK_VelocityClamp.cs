﻿/***************************************************
File:           LPK_VelocityClamp
Authors:        Christopher Onorati
Last Updated:   5/16/2019
Last Version:   2018.3.14

Description:
  This component can be added to any object with a
  RigidBody2D to clamp velocity settings.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_VelocityClamp
* DESCRIPTION : This component can be added to any game object to clamp velocity of the object.
**/
[RequireComponent(typeof(Rigidbody2D))]
public class LPK_VelocityClamp : LPK_Component
{
    /************************************************************************************/

    public enum LPK_VelocityClampMode
    {
        VELOCITY_MAGNITUDE,
        VELOCITY_DIRECTION,
    };

    /************************************************************************************/

    public LPK_VelocityClampMode m_eVelocityClampMode;

    //Clamp magnitude
    public bool m_bClampXVelocity;
    public Vector2 m_vecXVelocity = new Vector2(-10.0f, 10.0f);

    public bool m_bClampYVelocity;
    public Vector2 m_vecYVelocity = new Vector2(-10.0f, 10.0f);

    //Clamp direction.
    public bool m_bClampXDirection;
    public Vector2 m_vecXDirectionClamps = new Vector2(-0.5f, 0.5f);

    public bool m_bClampYDirection;
    public Vector2 m_vecYDirectionClamps = new Vector2(-0.5f, 0.5f);

    /************************************************************************************/

    Rigidbody2D m_cRigidbody;

    Vector2 m_vecPreviousVelocity;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Save out the Rigidbody2D component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        m_cRigidbody = GetComponent<Rigidbody2D>();
    }

    /**
    * FUNCTION NAME: FixedUpdate
    * DESCRIPTION  : Apply velocity clamps.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void FixedUpdate()
    {
        m_vecPreviousVelocity = m_cRigidbody.velocity;

        //Magnitude clamp.
        if(m_eVelocityClampMode == LPK_VelocityClampMode.VELOCITY_MAGNITUDE)
        {
            if(m_bClampXVelocity)
                Mathf.Clamp(m_cRigidbody.velocity.x, m_vecXVelocity.x, m_vecXVelocity.y);

            if(m_bClampYVelocity)
                Mathf.Clamp(m_cRigidbody.velocity.y, m_vecYVelocity.x, m_vecYVelocity.y);
        }

        //Direction clamp.
        else if (m_eVelocityClampMode == LPK_VelocityClampMode.VELOCITY_DIRECTION)
        {
            Vector2 vecNormalizedDir = m_cRigidbody.velocity.normalized;
            Vector2 magnitude = m_cRigidbody.velocity / vecNormalizedDir;

            if(m_bClampXDirection)
                Mathf.Clamp(m_cRigidbody.velocity.x, m_vecXDirectionClamps.x, m_vecXDirectionClamps.y);
            
            if(m_bClampYDirection)
                Mathf.Clamp(m_cRigidbody.velocity.y, m_vecYDirectionClamps.x, m_vecYDirectionClamps.y);

            m_cRigidbody.velocity *= magnitude;
        }

        //Debug.
        if(m_vecPreviousVelocity != m_cRigidbody.velocity && m_bPrintDebug)
            LPK_PrintDebug(this, "Velocity clamped.");
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_VelocityClamp))]
public class LPK_VelocityClampEditor : Editor
{
    SerializedProperty velocityClampMode;
    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        velocityClampMode = serializedObject.FindProperty("m_eVelocityClampMode");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_VelocityClamp owner = (LPK_VelocityClamp)target;

        LPK_VelocityClamp editorOwner = owner.GetComponent<LPK_VelocityClamp>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_VelocityClamp)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_VelocityClamp), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_VelocityClamp");

        //Component properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(velocityClampMode, true);

        if(velocityClampMode.enumValueIndex == (int)LPK_VelocityClamp.LPK_VelocityClampMode.VELOCITY_MAGNITUDE)
        {
            owner.m_bClampXVelocity = EditorGUILayout.Toggle(new GUIContent("Clamp X Velocity", "Should this object's X velocity speed be clamped?"), owner.m_bClampXVelocity);

            if(owner.m_bClampXVelocity)
                owner.m_vecXVelocity = EditorGUILayout.Vector2Field(new GUIContent("X Velocity Clamps", "Limits for this game object's X velocity magnitude."), owner.m_vecXVelocity);

            owner.m_bClampYVelocity = EditorGUILayout.Toggle(new GUIContent("Clamp Y Velocity", "Should this object's Y velocity speed be clamped?"), owner.m_bClampYVelocity);

            if(owner.m_bClampYVelocity)
                owner.m_vecYVelocity = EditorGUILayout.Vector2Field(new GUIContent("Y Velocity Clamps", "Limits for this game object's Y velocity magnitude."), owner.m_vecYVelocity);
        }

        else if (velocityClampMode.enumValueIndex == (int)LPK_VelocityClamp.LPK_VelocityClampMode.VELOCITY_DIRECTION)
        {
            owner.m_bClampXDirection = EditorGUILayout.Toggle(new GUIContent("Clamp X Direction", "Should this object's X velocity direction be clamped?"), owner.m_bClampXDirection);

            if(owner.m_bClampXDirection)
                owner.m_vecXDirectionClamps = EditorGUILayout.Vector2Field(new GUIContent("X Direction Clamps", "Limits for this game object's X velocity direction. Values should be -1 to 1."), owner.m_vecXDirectionClamps);

            owner.m_bClampYDirection = EditorGUILayout.Toggle(new GUIContent("Clamp Y Velocity", "Should this object's Y velocity direction be clamped?"), owner.m_bClampYDirection);

            if(owner.m_bClampYDirection)
                owner.m_vecYDirectionClamps = EditorGUILayout.Vector2Field(new GUIContent("Y Direction Clamps", "Limits for this game object's Y velocity direction. Values should be -1 to 1."), owner.m_vecYDirectionClamps);
        }

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK