﻿/***************************************************
File:           LPK_FaceVelocity.cs
Authors:        Christopher Onorati
Last Updated:   5/16/2019
Last Version:   2018.3.14

Description:
  This component causes an object to face its velocity
  either on start or every frame.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_FaceVelocity
* DESCRIPTION : Basic facing component.
**/
[RequireComponent(typeof(Rigidbody2D))]
public class LPK_FaceVelocity : LPK_Component
{
    /************************************************************************************/

    public bool m_bEveryFrame = true;

    /************************************************************************************/

    Transform m_cTransform;
    Rigidbody2D m_cRigidBody;

    /**
     * FUNCTION NAME: OnStart
     * DESCRIPTION  : Checks to ensure proper components are on the object for facing.
     * INPUTS       : None
     * OUTPUTS      : None
     **/
    override protected void OnStart()
    {
        m_cTransform = GetComponent<Transform>();
        m_cRigidBody = GetComponent<Rigidbody2D>();

        if (!m_bEveryFrame)
        {
            Vector2 dir = m_cRigidBody.velocity;
            float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            m_cTransform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }

    /**
    * FUNCTION NAME: Update
    * DESCRIPTION  : Manages facing direction if user specified every frame updating.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Update()
    {
        if (!m_bEveryFrame)
            return;

        Vector2 dir = m_cRigidBody.velocity;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        m_cTransform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_FaceVelocity))]
public class LPK_FaceVelocityEditor : Editor
{
    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_FaceVelocity owner = (LPK_FaceVelocity)target;

        LPK_FaceVelocity editorOwner = owner.GetComponent<LPK_FaceVelocity>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_FaceVelocity)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_FaceVelocity), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_FaceVelocity");

        //Component properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        owner.m_bEveryFrame = EditorGUILayout.Toggle(new GUIContent("Every Frame", "Whether to update the object to face velocity on start or every frame."), owner.m_bEveryFrame);
    }
}

#endif  //UNITY_EDTIOR

}   //LPK
