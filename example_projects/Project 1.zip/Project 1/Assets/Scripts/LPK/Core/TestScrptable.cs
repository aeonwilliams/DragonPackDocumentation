﻿using UnityEngine;

[CreateAssetMenu(fileName = "Event Label", menuName = "LPK/Event Object")]
public class TestScrptable : ScriptableObject
{
}
