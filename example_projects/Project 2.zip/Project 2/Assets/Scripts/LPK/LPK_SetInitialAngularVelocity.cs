﻿/***************************************************
File:           LPK_SetInitialAngularVelocity
Authors:        Christopher Onorati
Last Updated:   5/16/19
Last Version:   2018.3.14

Description:
  This component can be added to any object with a
  RigidBody to cause it to apply an initial angular velocity.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_SetInitialAngularVelocity
* DESCRIPTION : This component can be added to any object with a RigidBody to cause it to spawn with a set angular velocity.
**/
[RequireComponent(typeof(Transform), typeof(Rigidbody2D))]
public class LPK_SetInitialAngularVelocity : LPK_Component
{
    /************************************************************************************/

    public bool m_bEveryFrame = false;

    public float m_flAngularForce = 5;
    public float m_flVariance;

    /************************************************************************************/

    Rigidbody2D m_cRigidBody;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Applies initial angular velocity and sets rigidbody component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        m_cRigidBody = GetComponent<Rigidbody2D>();

        if (!m_bEveryFrame)
        {
            ApplyVelocity();
            enabled = false;
        }
    }

    /**
    * FUNCTION NAME: FixedUpdate
    * DESCRIPTION  : Applies ongoing velocity if appropriate.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void FixedUpdate()
    {
        if (m_bEveryFrame)
            ApplyVelocity();
    }

    /**
    * FUNCTION NAME: ApplyVelocity
    * DESCRIPTION  : Manages velocity change on object with component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void ApplyVelocity()
    {
        float frameForce = m_flAngularForce + Random.Range(-m_flVariance, m_flVariance);

        m_cRigidBody.angularVelocity = frameForce;

        if (m_bPrintDebug)
            LPK_PrintDebug(this, "Angular Velocity Applied");
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_SetInitialAngularVelocity))]
public class LPK_SetInitialAngularVelocityEditor : Editor
{
    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_SetInitialAngularVelocity owner = (LPK_SetInitialAngularVelocity)target;

        LPK_SetInitialAngularVelocity editorOwner = owner.GetComponent<LPK_SetInitialAngularVelocity>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_SetInitialAngularVelocity)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_SetInitialAngularVelocity), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_SetInitialAngularVelocity");

        //Component properties
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        owner.m_bEveryFrame = EditorGUILayout.Toggle(new GUIContent("Every Frame", "Whether the velocity should ba applied every frame. Will only be applied on initialize otherwise."), owner.m_bEveryFrame);
        owner.m_flAngularForce = EditorGUILayout.FloatField(new GUIContent("Force", "Angular force to be applied."), owner.m_flAngularForce);
        owner.m_flVariance = EditorGUILayout.FloatField(new GUIContent("Variance", "Variance to apply to Force for randomized movement."), owner.m_flVariance);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}
