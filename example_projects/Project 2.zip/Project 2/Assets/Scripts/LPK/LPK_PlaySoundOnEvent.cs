﻿/***************************************************
File:           LPK_PlaySoundOnEvent
Authors:        Christopher Onorati
Last Updated:   5/20/2019
Last Version:   2018.3.14

Description:
  This component can be added to any object to play a 
  sound upon receving an event notice.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using System.Collections.Generic;
using System.Collections;
using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_PlaySoundOnEvent
* DESCRIPTION : Plays a sound effect when an event is sent and parsed.
**/
public class LPK_PlaySoundOnEvent : LPK_Component
{
    /************************************************************************************/

    [Tooltip("Object(s) whose emitter will be used to play sound. Set to owner by default if both this and the tagged objects array are left empty.")]
    public GameObject[] m_TargetObjects;

    [Tooltip("Tagged object(s) whose emitter will be used to play sound. Set to owner by default if both this and the game object array are left empty.")]
    [TagDropdown]
    public string[] m_TargetTags;

    public Vector2 m_vecVolumeRange = new Vector2(1, 1);
    public Vector2 m_vecPitchRange = new Vector2(1, 1);

    public float m_flCooldown = 0.0f;

    [Header("Event Receiving Info")]

    [Tooltip("Which event will trigger this component's action")]
    public LPK_EventObject m_EventTrigger;

    /************************************************************************************/

    //Whether this component is waiting its cooldown
    bool m_bOnCooldown = false;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Sets up what event to listen to for sound playback.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        if(m_EventTrigger)
            m_EventTrigger.Register(this);

        if(m_TargetObjects.Length == 0 && m_TargetTags.Length == 0)
        {
            if (GetComponent<AudioSource>() != null )
                m_TargetObjects = new GameObject[] { gameObject };
        }
    }

    /**
    * FUNCTION NAME: OnEvent
    * DESCRIPTION  : Event validation.
    * INPUTS       : _activator - Game object that activated the event.  Null is all objects.
    * OUTPUTS      : None
    **/
    override public void OnEvent(GameObject _activator)
    {
        if(!ShouldRespondToEvent(_activator))
            return;

        if(m_bOnCooldown)
        {
            if(m_bPrintDebug)
                LPK_PrintDebug(this, "On cool down.");
            return;
        }

        if (m_bPrintDebug)
            LPK_PrintDebug(this, "Event received.");

        for(int i = 0; i < m_TargetObjects.Length; i++)
        {
            if (m_TargetObjects[i].GetComponent<AudioSource>() != null)
            {
                m_TargetObjects[i].GetComponent<AudioSource>().volume = Random.Range(m_vecVolumeRange.x, m_vecVolumeRange.y);
                m_TargetObjects[i].GetComponent<AudioSource>().pitch = Random.Range(m_vecPitchRange.x, m_vecPitchRange.y);
                m_TargetObjects[i].GetComponent<AudioSource>().Play();
            }
        }

        for (int i = 0; i < m_TargetTags.Length; i++)
        {
            List<GameObject> taggedObjects = LPK_MultiTagManager.FindGameObjectsWithTag(gameObject, m_TargetTags[i]);

            for(int j = 0; j < taggedObjects.Count; j++)
            {
                if (taggedObjects[j].GetComponent<AudioSource>() != null)
                {
                    taggedObjects[i].GetComponent<AudioSource>().volume = Random.Range(m_vecVolumeRange.x, m_vecVolumeRange.y);
                    taggedObjects[i].GetComponent<AudioSource>().pitch = Random.Range(m_vecPitchRange.x, m_vecPitchRange.y);
                    taggedObjects[j].GetComponent<AudioSource>().Play();
                }
            }
        }

        m_bOnCooldown = true;
        StartCoroutine(CoolDownDelay());
    }

    /**
    * FUNCTION NAME: CoolDownDelay
    * DESCRIPTION  : Forces cooldown between calls to play the sound effect.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    IEnumerator CoolDownDelay()
    {
        yield return new WaitForSeconds(m_flCooldown);
        m_bOnCooldown = false;
    }

    /**
    * FUNCTION NAME: OnDestroy
    * DESCRIPTION  : Removes game object from the event queue.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnDestroy()
    {
        if(m_EventTrigger != null)
            m_EventTrigger.Unregister(this);
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_PlaySoundOnEvent))]
public class LPK_PlaySoundOnEventEditor : Editor
{
    SerializedProperty targetObjects;
    SerializedProperty targetTags;

    SerializedProperty eventTriggers;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        targetObjects = serializedObject.FindProperty("m_TargetObjects");
        targetTags = serializedObject.FindProperty("m_TargetTags");

        eventTriggers = serializedObject.FindProperty("m_EventTrigger");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_PlaySoundOnEvent owner = (LPK_PlaySoundOnEvent)target;

        LPK_PlaySoundOnEvent editorOwner = owner.GetComponent<LPK_PlaySoundOnEvent>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_PlaySoundOnEvent)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_PlaySoundOnEvent), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_PlaySoundOnEvent");

        //Component properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(targetObjects, true);
        EditorGUILayout.PropertyField(targetTags, true);
        owner.m_vecVolumeRange = EditorGUILayout.Vector2Field(new GUIContent("Volume Variance", "Minimum and maximum volume for the sound to be played at.  The volume will be randomized each time the sound is called to be played."), owner.m_vecVolumeRange);
        owner.m_vecPitchRange = EditorGUILayout.Vector2Field(new GUIContent("Pitch Variance", "Minimum and maximum pitch for the sound to be played at.  The pitch will be randomized each time the sound is called to be played."), owner.m_vecVolumeRange);
        owner.m_flCooldown = EditorGUILayout.FloatField(new GUIContent("Cooldown", "Number of seconds to wait until an event can trigger another instance of sound played."), owner.m_flCooldown);

        //Events
        EditorGUILayout.PropertyField(eventTriggers, true);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
