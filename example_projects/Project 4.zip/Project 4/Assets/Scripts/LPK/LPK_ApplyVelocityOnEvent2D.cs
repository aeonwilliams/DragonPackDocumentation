﻿/***************************************************
File:           LPK_ApplyVelocityOnEvent2D
Authors:        Christopher Onorati
Last Updated:   8/1/2019
Last Version:   2018.3.14

Description:
  This component can be used to apply velocity to Rigidbody2D
  components when an event is recieved.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_ApplyVelocityOnEvent2D
* DESCRIPTION : This component can be added to any game object with a RigidBody to make it recieve a change in
*               velocity when an event is received.
**/
public class LPK_ApplyVelocityOnEvent2D : LPK_Component
{
    /************************************************************************************/

    public enum LPK_VelocityApplyMode
    {
        DIRECTION,
        TARGET, 
    };

    /************************************************************************************/

    [Header("Component Properties")]

    [Tooltip("How to determine how velocity is applied to a game object when an event is recieved.  TARGET = Home in on a game object.  DIRECTION = Set velocity in a specific direction.")]
    [Rename("Velocity Application Mode")]
    public LPK_VelocityApplyMode m_eVelocityApplicationMode;

    [Tooltip("Game object to move towards.  If set to null, try to find the first object with the specified tag.")]
    [Rename("Target Game Object")]
    public Transform m_pTargetGameObject;

    [Tooltip("Tags to move the object towards.  This will start at the top trying to find the first object of the tag.")]
    [TagDropdown]
    public string[] m_TargetTags;

    public float m_flRadius = 10.0f;

    public Vector3 m_vecDirection;

    [Tooltip("RigidBody2D components to change the velocity on.")]
    public Rigidbody2D[] m_ModifyRigidBody2Ds;

    public float m_flSpeed = 5;

    [Header("Event Receiving Info")]

    [Tooltip("Which event will trigger this component's action")]
    public LPK_EventObject m_EventTrigger;

    /************************************************************************************/
    
    /**
    * FUNCTION NAME: Start
    * DESCRIPTION  : Sets rigidbody component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Start()
    {
        if(m_EventTrigger)
            m_EventTrigger.Register(this);
    }

    /**
    * FUNCTION NAME: OnEvent
    * DESCRIPTION  : Event validation.
    * INPUTS       : _activator - Game object that activated the event.  Null is all objects.
    * OUTPUTS      : None
    **/
    override public void OnEvent(GameObject _activator)
    {
        if(!ShouldRespondToEvent(_activator))
            return;

        if(m_bPrintDebug)
            LPK_PrintDebug(this, "Event received.");

        ApplyVelocity();
    }

    /**
     * FUNCTION NAME: ApplyVelocity
     * DESCRIPTION  : Applies velocity to object.
     * INPUTS       : None
     * OUTPUTS      : None
     **/
    void ApplyVelocity()
    {
        if (m_eVelocityApplicationMode == LPK_VelocityApplyMode.TARGET)
        {
            if (m_pTargetGameObject == null)
            {
                if (!FindGameObject())
                    return;
            }

            for(int i = 0; i < m_ModifyRigidBody2Ds.Length; i++)
                m_ModifyRigidBody2Ds[i].velocity = (m_pTargetGameObject.position - m_ModifyRigidBody2Ds[i].transform.position).normalized * m_flSpeed;
        }
        else if (m_eVelocityApplicationMode == LPK_VelocityApplyMode.DIRECTION)
        {
            for(int i = 0; i < m_ModifyRigidBody2Ds.Length; i++)
                m_ModifyRigidBody2Ds[i].velocity = m_vecDirection.normalized * m_flSpeed;       
        }
    }

    /**
     * FUNCTION NAME: FindGameObject
     * DESCRIPTION  : Applies ongoing velocity if appropriate.
     * INPUTS       : None
     * OUTPUTS      : bool - True/false of if a game object was found and set.
     **/
    bool FindGameObject()
    {
        for (int i = 0; i < m_TargetTags.Length; i++)
        {
            List<GameObject> objects = new List<GameObject>();
            GetGameObjectsInRadius(objects, m_flRadius, 1, m_TargetTags[i]);

            if(objects[0] != null)
            {
                m_pTargetGameObject = objects[0].transform;
                return true;
            }
        }

        return false;
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_ApplyVelocityOnEvent2D))]
public class LPK_ApplyVelocityOnEvent2DEditor : Editor
{
    SerializedProperty m_eVelocityApplicationMode;
    SerializedProperty targetObject;
    SerializedProperty targetTags;
    SerializedProperty m_ModifyRigidBody2Ds;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        m_eVelocityApplicationMode = serializedObject.FindProperty("m_eVelocityApplicationMode");
        targetObject = serializedObject.FindProperty("m_pTargetGameObject");
        targetTags = serializedObject.FindProperty("m_TargetTags");
        m_ModifyRigidBody2Ds = serializedObject.FindProperty("m_ModifyRigidBody2Ds");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_ApplyVelocityOnEvent2D owner = (LPK_ApplyVelocityOnEvent2D)target;

        LPK_ApplyVelocityOnEvent2D editorOwner = owner.GetComponent<LPK_ApplyVelocityOnEvent2D>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_ApplyVelocityOnEvent2D)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_ApplyVelocityOnEvent2D), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_ApplyVelocityOnEvent2D");

        //Component properties.
        EditorGUILayout.PropertyField(m_eVelocityApplicationMode, true);

        if(m_eVelocityApplicationMode.enumValueIndex == (int)LPK_ApplyVelocityOnEvent2D.LPK_VelocityApplyMode.TARGET)
        {
            EditorGUILayout.PropertyField(targetObject, true);
            LPK_EditorArrayDraw.DrawArray(targetTags, LPK_EditorArrayDraw.LPK_EditorArrayDrawMode.DRAW_MODE_BUTTONS);
            owner.m_flRadius = EditorGUILayout.FloatField(new GUIContent("Detect Radius", "Max distance used to search for game objects.  If set to 0, detect objects anywhere."), owner.m_flRadius);
        }
        else if (m_eVelocityApplicationMode.enumValueIndex == (int)LPK_ApplyVelocityOnEvent2D.LPK_VelocityApplyMode.DIRECTION)
            EditorGUILayout.Vector3Field(new GUIContent("Direction", "Direction to set the velocity of the RigidBody2D towards.  This value will be normalized."), owner.m_vecDirection);

        EditorGUILayout.PropertyField(m_ModifyRigidBody2Ds, true);

        owner.m_flSpeed = EditorGUILayout.FloatField(new GUIContent("Force", "Force to be applied."), owner.m_flSpeed);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
