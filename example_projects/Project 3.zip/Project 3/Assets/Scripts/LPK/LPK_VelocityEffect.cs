﻿/***************************************************
File:           LPK_VelocityEffect
Authors:        Christopher Onorati
Last Updated:   5/20/2019
Last Version:   2018.3.14

Description:
  This component can be added to any object with a
  RigidBody to cause it to apply a custom velocity.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_VelocityEffect
* DESCRIPTION : This component can be added to any object with a RigidBody to cause it to apply a custom velocity.
**/
[RequireComponent(typeof(Transform), typeof(Rigidbody2D))]
public class LPK_VelocityEffect : LPK_Component
{
    /************************************************************************************/

    public enum LPK_VelocityApplyDirection
    {
        WORLD,
        LOCAL,
    };

    public enum LPK_VelocityApplyMode
    {
        SET,
        ADD,
    };

    /************************************************************************************/

    public bool m_bEveryFrame = false;

    [Tooltip("Whether the velocity should be applied Locally or Globally")]
    [Rename("Direction")]
    public LPK_VelocityApplyDirection m_eDirection = LPK_VelocityApplyDirection.WORLD;

    [Tooltip("Whether velocity should be Added or Set")]
    [Rename("Mode")]
    public LPK_VelocityApplyMode m_eMode = LPK_VelocityApplyMode.SET;

    public Vector3 m_vecForward = new Vector3(0, 1, 0);

    public float m_flSpeed = 5;

    /************************************************************************************/

    Transform m_cTransform;
    Rigidbody2D m_cRigidBody;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Applies initial velocity if appropriate and sets rigidbody component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        m_cTransform = GetComponent<Transform>();
        m_cRigidBody = GetComponent<Rigidbody2D>();

        if (!m_bEveryFrame)
            ApplyVelocity();
    }

    /**
    * FUNCTION NAME: Update
    * DESCRIPTION  : Applies ongoing velocity if appropriate.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void Update()
    {
        if (m_bEveryFrame)
            ApplyVelocity();
	}

   /**
   * FUNCTION NAME: ApplyVelocity
   * DESCRIPTION  : Manages velocity change on object with component.
   * INPUTS       : None
   * OUTPUTS      : None
   **/
    void ApplyVelocity()
    {
        if (m_eDirection == LPK_VelocityApplyDirection.LOCAL)
        {
            if (m_eMode == LPK_VelocityApplyMode.SET)
                m_cRigidBody.velocity = m_cTransform.TransformDirection(m_vecForward) * m_flSpeed;
            else
                m_cRigidBody.velocity += (Vector2)m_cTransform.TransformDirection(m_vecForward) * m_flSpeed;
        }
        else
        {
            if (m_eMode == LPK_VelocityApplyMode.SET)
                m_cRigidBody.velocity = m_vecForward * m_flSpeed;
            else
                m_cRigidBody.velocity += (Vector2)m_vecForward * m_flSpeed;
        }

        if (m_bPrintDebug)
            LPK_PrintDebug(this, "Velocity Applied");
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_VelocityEffect))]
public class LPK_VelocityEffectEditor : Editor
{
    SerializedProperty direction;
    SerializedProperty mode;

    SerializedProperty eventTriggers;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        direction = serializedObject.FindProperty("m_eDirection");
        mode = serializedObject.FindProperty("m_eMode");

        eventTriggers = serializedObject.FindProperty("m_EventTrigger");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_VelocityEffect owner = (LPK_VelocityEffect)target;

        LPK_VelocityEffect editorOwner = owner.GetComponent<LPK_VelocityEffect>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_VelocityEffect)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_VelocityEffect), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_VelocityEffect");

        //Component properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        owner.m_bEveryFrame = EditorGUILayout.Toggle(new GUIContent("Every Frame", "Whether the velocity should ba applied every frame. Will only be applied on initialize otherwise."), owner.m_bEveryFrame);
        EditorGUILayout.PropertyField(direction, true);
        EditorGUILayout.PropertyField(mode, true);
        owner.m_vecForward = EditorGUILayout.Vector3Field(new GUIContent("Forward", "Direction to apply the velocity in."), owner.m_vecForward);
        owner.m_flSpeed = EditorGUILayout.FloatField(new GUIContent("Speed", "Magnitude of the speed to be applied."), owner.m_flSpeed);

        //Events
        EditorGUILayout.PropertyField(eventTriggers, true);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
