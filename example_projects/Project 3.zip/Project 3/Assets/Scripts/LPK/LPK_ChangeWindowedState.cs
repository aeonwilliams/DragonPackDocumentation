﻿/***************************************************
File:           LPK_ChangeWindowedState.cs
Authors:        Christopher Onorati
Last Updated:   3/30/2019
Last Version:   2018.3.14

Description:
  This component can be used to change the fullscreen mode
  of the game window during runtime.  This component is
  ideally used on an options menu.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_ChangeWindowedState
* DESCRIPTION : Component used to change windowed state of game.
**/
public class LPK_ChangeWindowedState : LPK_Component
{
    /************************************************************************************/

    public enum LPK_WindowToggleType
    {
        CHANGE_FULLSCREEN,
        CHANGE_WINDOWED,
        CHANGE_TOGGLE,
    };

    /************************************************************************************/

    [Tooltip("How to change the windowed state when activated via event.")]
    [Rename("Toggle Type")]
    public LPK_WindowToggleType m_eWindowToggleType;

    /**
    * FUNCTION NAME: SetWindowType
    * DESCRIPTION  : Changes windowed state.  Moved to public so UI buttons can interact with this.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public void SetWindowType()
    {
        if (m_eWindowToggleType == LPK_WindowToggleType.CHANGE_FULLSCREEN)
            Screen.fullScreen = true;
        else if (m_eWindowToggleType == LPK_WindowToggleType.CHANGE_WINDOWED)
            Screen.fullScreen = false;
        else
            Screen.fullScreen = !Screen.fullScreen;
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_ChangeWindowedState))]
public class LPK_ChangeWindowedStateEditor : Editor
{
    SerializedProperty windowToggleType;

    /**
    * FUNCTION NAME: OnEnable
    * DESCRIPTION  : Save out serialized classes.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void OnEnable()
    {
        windowToggleType = serializedObject.FindProperty("m_eWindowToggleType");
    }

    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_ChangeWindowedState owner = (LPK_ChangeWindowedState)target;

        LPK_ChangeWindowedState editorOwner = owner.GetComponent<LPK_ChangeWindowedState>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_ChangeWindowedState)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_ChangeWindowedState), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_ChangeWindowedState");

        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        EditorGUILayout.PropertyField(windowToggleType, true);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
