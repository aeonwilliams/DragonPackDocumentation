﻿/***************************************************
File:           LPK_SetInitialVelocity
Authors:        Christopher Onorati
Last Updated:   5/16/2019
Last Version:   2018.3.14

Description:
  This component can be added to any object with a
  RigidBody to cause it to apply an initial velocity.

This script is a basic and generic implementation of its 
functionality. It is designed for educational purposes and 
aimed at helping beginners.

Copyright 2018-2019, DigiPen Institute of Technology
***************************************************/

using UnityEngine;
using UnityEditor;

namespace LPK
{

/**
* CLASS NAME  : LPK_SetInitialVelocity
* DESCRIPTION : This component can be added to any object with a RigidBody to cause it to spawn with a set velocity.
**/
[RequireComponent(typeof(Transform), typeof(Rigidbody2D))]
public class LPK_SetInitialVelocity : LPK_Component
{
    /************************************************************************************/

    public bool m_bEveryFrame = false;

    public Vector3 m_vecDir;
    public Vector3 m_vecVariance;

    public float m_flSpeed = 5;

    /************************************************************************************/

    Rigidbody2D m_cRigidBody;

    /**
    * FUNCTION NAME: OnStart
    * DESCRIPTION  : Applies initial velocity and sets rigidbody component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    override protected void OnStart()
    {
        m_cRigidBody = GetComponent<Rigidbody2D>();

        if (!m_bEveryFrame)
        {
            ApplyVelocity();
            enabled = false;
        }
    }

    /**
    * FUNCTION NAME: FixedUpdate
    * DESCRIPTION  : Applies ongoing velocity if appropriate.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void FixedUpdate()
    {
        ApplyVelocity();
    }

    /**
    * FUNCTION NAME: ApplyVelocity
    * DESCRIPTION  : Manages velocity change on object with component.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    void ApplyVelocity()
    {
        Vector3 dir = m_vecDir;
        dir.x += Random.Range(-m_vecVariance.x, m_vecVariance.x);
        dir.y += Random.Range(-m_vecVariance.y, m_vecVariance.y);
        dir.z += Random.Range(-m_vecVariance.z, m_vecVariance.z);

        m_cRigidBody.velocity = dir * m_flSpeed;

        if (m_bPrintDebug)
            LPK_PrintDebug(this, "Velocity Applied");
    }
}

#if UNITY_EDITOR

[CustomEditor(typeof(LPK_SetInitialVelocity))]
public class LPK_SetInitialVelocityEditor : Editor
{
    /**
    * FUNCTION NAME: OnInspectorGUI
    * DESCRIPTION  : Override GUI for inspector.
    * INPUTS       : None
    * OUTPUTS      : None
    **/
    public override void OnInspectorGUI()
    {
        LPK_SetInitialVelocity owner = (LPK_SetInitialVelocity)target;

        LPK_SetInitialVelocity editorOwner = owner.GetComponent<LPK_SetInitialVelocity>();

        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Script");
        editorOwner = (LPK_SetInitialVelocity)EditorGUILayout.ObjectField(editorOwner, typeof(LPK_SetInitialVelocity), false);
        GUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        //Undo saving.
        Undo.RecordObject(owner, "Property changes on LPK_SetInitialVelocity");

        //Component properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Component Properties", EditorStyles.boldLabel);

        owner.m_bEveryFrame = EditorGUILayout.Toggle(new GUIContent("Every Frame", "Whether the velocity should ba applied every frame. Will only be applied on initialize otherwise."), owner.m_bEveryFrame);
        owner.m_vecDir = EditorGUILayout.Vector3Field(new GUIContent("Direction", "What direction to apply the velocity in."), owner.m_vecDir);
        owner.m_vecVariance = EditorGUILayout.Vector3Field(new GUIContent("Variance", "Variance to apply to Direction for randomized movement."), owner.m_vecVariance);
        owner.m_flSpeed = EditorGUILayout.FloatField(new GUIContent("Speed", "Force to be applied"), owner.m_flSpeed);

        //Debug properties.
        GUILayout.Space(10);
        EditorGUILayout.LabelField("Debug Properties", EditorStyles.boldLabel);

        owner.m_bPrintDebug = EditorGUILayout.Toggle(new GUIContent("Print Debug Info", "Toggle console debug messages."), owner.m_bPrintDebug);
        owner.m_sLabel = EditorGUILayout.TextField(new GUIContent("Label", "Notes for the user about this component.  This does nothing to the game or build."), owner.m_sLabel);

        //Apply changes.
        serializedObject.ApplyModifiedProperties();
    }
}

#endif  //UNITY_EDITOR

}   //LPK
